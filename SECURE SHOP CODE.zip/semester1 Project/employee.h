#include <iostream>
#include <fstream>
#include<iomanip>
void viewSupportRequests();
void updateSupportRequestStatus(const char* username, const char* query);
void feedbackresponses(char* response, char* username);
void displayfeedback();
//functions prototypes inventory management kai liye
void loadProductsFromFile(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int& productCount,int thresholds[]);
void saveProductsToFile(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int productCount);
void addProduct(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int& productCount, int thresholds[]);
void editProduct(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int productCount);
void adjustStock(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int productCount);
bool deleteProduct(char* productID);
void checkLowStock(int productIDs[], char names[][50], int stock[], int thresholds[], int productCount);
void setAllThresholdsTo10(int thresholds[], int productCount);





