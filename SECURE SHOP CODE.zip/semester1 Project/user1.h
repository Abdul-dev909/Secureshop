
#include <iostream>
#include <fstream>
void initializeUsers();
bool registerUser(const char* username, const char* password, const char* role);
bool loginUser(char* username,  char* password);
int rolecheck(char*);
void productcatalog();
int strcmp1(char*, char*);
bool addFeedbackToFile(const char* itemId, const char* itemName, const char* feedback,const char* name);
//Wishlist walay functions ki prototypes:
bool clearWishlist();
bool addToWishlist(const char* itemId);
void viewWishlist();
//supportrequest walay function ki prototype
bool submitSupportRequest(const char* username, const char* message);




