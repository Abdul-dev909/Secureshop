#include<iostream>
#include<fstream>
void adminMenu();
void addUser(const char* username, const char* password, const char* role);
void listUsers();
bool modifyUser(char* targetUsername, const char* newUsername, const char* newPassword, const char* newRole);
bool removeUser(char* targetUsername);
bool bulkImport();
bool bulkExport();




