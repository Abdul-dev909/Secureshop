#include <iostream>
#include <fstream>
#include<iomanip>
void productcatalog();

void filterbycat(char*);
int strcmp1(char*, char*);
bool additemstocart(char*);
void clearCart();
bool removeSpecificItem(char*);
void updateStock(char*, int);
void displaycart(void);
bool applyDiscount(const char*,float&);
float calculateTotalAndStoreHistory(const char*, const char*, float);
bool confirmPurchaseBackend(const char* , const char* ,float);
