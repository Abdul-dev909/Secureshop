#include "user1.h" // User-related functions ka header include
#include "product.h" // Product-related functions ka header include
#include "employee.h" // Employee-related functions ka header include
#include "admin.h" //admin related saary functions ka header include

using namespace std;

int main() {
    char username[30], password[20], role[10];
    int choice;

    cout << "WELCOME TO ABDUL's SECURE SHOP!\n";
    cout << "SecureShop Main Menu:\n";
    cout << "1. Register\n";
    cout << "2. Login\n";
    cout << "3. Exit\n";
    cout << "Enter your choice: ";
    cin >> choice;
    cin.ignore(10000, '\n'); // Buffer clear karne ke liye

    switch (choice) {
    case 1: {
        cout << "Enter Username: ";
        cin.getline(username, 30); // Username input
        cout << "Enter Password: ";
        cin.getline(password, 20); // Password input
        cout << "Enter Role (Customer/Employee/Admin): ";
        cin.getline(role, 10); // Role input

        if (registerUser(username, password, role)) {
            cout << "Registration successful.\n";
        }
        else {
            cout << "Registration failed.\n";
        }
        break;
    }

    case 2: {
        cout << "Enter Username: ";
        cin.getline(username, 30);
        cout << "Enter Password: ";
        cin.getline(password, 20);
        cout << "Enter Role: ";
        cin.getline(role, 10);

        if (loginUser(username, password)) {
            int rol = rolecheck(role);

            if (rol == 2) { // Customer
                int customerChoice = 0;
                cout << "\n=========== Logged in as a customer! ===========\n";
                cout << "---------- DISCOUNT CODES FOR NEW CUSTOMERS ----------\n";
                cout << "\n---------------------- 'SAVE10', 'WELCOME5', 'SHOP20' ----------------------\n";

                do {
                    cout << "\n=========== Customer Menu ===========\n\n";
                    cout << "1: Product catalog.\n";
                    cout << "2: Filter product by Category.\n";
                    cout << "3: Add Items to Cart.\n";
                    cout << "4: Remove a specific item from the cart.\n";
                    cout << "5: Remove all items from the cart.\n";
                    cout << "6: Proceed to Checkout.\n";
                    cout << "7: Give Feedback.\n";
                    cout << "8: Open Wishlist options.\n";
                    cout << "9: Support Request.\n";
                    cout << "10: Logout.\n";
                    cout << "Enter your choice: ";
                    cin >> customerChoice;
                    cin.ignore();

                    switch (customerChoice) {
                    case 1:
                        productcatalog();
                        break;

                    case 2: {
                        char category[50];
                        cout << "Enter the category: ";
                        cin.getline(category, 50);
                        filterbycat(category);
                        break;
                    }

                    case 3: {
                        char id[10];
                        int addMoreItems = 0;
                        do {
                            productcatalog();
                            cout << "Enter the ID of the item you want to add to the cart: ";
                            cin.getline(id, 10);

                            if (additemstocart(id)) {
                                cout << "Item added to cart!\n";
                                cout << "Enter 1 to add more items or 0 to stop: ";
                                cin >> addMoreItems;
                                cin.ignore();
                            }
                            else {
                                cout << "Invalid item or not in stock.\n";
                            }
                        } while (addMoreItems != 0);
                        break;
                    }

                    case 4: {
                        char itemId[60];
                        productcatalog();
                        cout << "Enter the ID of the item to remove from the cart: ";
                        cin.getline(itemId, 60);

                        if (removeSpecificItem(itemId)) {
                            cout << "Item removed from cart!\n";
                            updateStock(itemId, 1);
                        }
                        else {
                            cout << "Item not found in cart!\n";
                        }
                        break;
                    }

                    case 5:
                        clearCart();
                        cout << "All items have been removed from your cart.\n";
                        break;

                    case 6: {
                        cout << "Proceeding to checkout...\n";
                        displaycart();

                        char discountCode[20];
                        cout << "Enter discount code (or leave blank if none): ";
                        cin.getline(discountCode, 20);

                        float discountRate = 0.0;
                        if (discountCode[0] != '\0' && applyDiscount(discountCode, discountRate)) {
                            cout << "Discount applied successfully (" << discountRate << "%).\n";
                        }
                        else if (discountCode[0] != '\0') {
                            cout << "Invalid discount code.\n";
                        }

                        cout << "Confirm purchase? (1 for Yes, 0 for No): ";
                        int confirmPurchase;
                        cin >> confirmPurchase;
                        cin.ignore();

                        if (confirmPurchase == 1) {
                            if (confirmPurchaseBackend("cart.txt", "orders.txt", discountRate)) {
                                cout << "Purchase confirmed! Thank you for shopping.\n";
                            }
                            else {
                                cout << "An error occurred. Please try again.\n";
                            }
                        }
                        else {
                            cout << "Purchase cancelled.\n";
                        }
                        break;
                    }

                    case 7: {
                        cout << "Enter the product ID you want to give feedback for: ";
                        char itemId[50];
                        cin >> itemId;
                        cin.ignore();

                        char* name = new char[20];
                        cout << "Enter your name: ";
                        cin.getline(name, 20);

                        cout << "Enter the product name: ";
                        char itemName[50];
                        cin.getline(itemName, 50);

                        cout << "Enter your feedback: ";
                        char feedback[256];
                        cin.getline(feedback, 256);

                        if (addFeedbackToFile(itemId, itemName, feedback, name)) {
                            cout << "Feedback added successfully!\n";
                        }
                        else {
                            cout << "Failed to add feedback.\n";
                        }
                        delete[] name;
                        break;
                    }

                    case 8: {
                        int wishlistChoice;
                        do {
                            cout << "\n=========== Wishlist Options ===========\n";
                            cout << "1. View Wishlist\n";
                            cout << "2. Add Item to Wishlist\n";
                            cout << "3. Clear Wishlist\n";
                            cout << "4. Back to Main Menu\n";
                            cout << "Enter your choice: ";
                            cin >> wishlistChoice;
                            cin.ignore();

                            if (wishlistChoice == 1) {
                                viewWishlist();
                            }
                            else if (wishlistChoice == 2) {
                                char itemId[50];
                                cout << "Enter Item ID: ";
                                cin.getline(itemId, 50);

                                if (addToWishlist(itemId)) {
                                    cout << "Item added to wishlist successfully!\n";
                                }
                                else {
                                    cout << "Failed to add item to wishlist.\n";
                                }
                            }
                            else if (wishlistChoice == 3) {
                                if (clearWishlist()) {
                                    cout << "Wishlist cleared successfully!\n";
                                }
                                else {
                                    cout << "Failed to clear wishlist.\n";
                                }
                            }
                        } while (wishlistChoice != 4);
                        break;
                    }

                    case 9: {
                        char username[50], message[500];
                        cout << "Enter your username: ";
                        cin.getline(username, 50);
                        cout << "Enter your message: ";
                        cin.getline(message, 500);

                        if (submitSupportRequest(username, message)) {
                            cout << "Support request submitted successfully! Our team will get back to you shortly.\n";
                        }
                        else {
                            cout << "Error submitting support request. Please try again later.\n";
                        }
                        break;
                    }

                    case 10:
                        cout << "Logging out...\n";
                        break;

                    default:
                        cout << "Invalid choice! Please try again.\n";
                    }
                } while (customerChoice != 10);
            }

            if (rol == 3) { // Employee
                int employeechoice = 0;

                do {
                    cout << "\n=========== Employee Menu ===========\n";
                    cout << "1: Support Management Options:\n";
                    cout << "2: Inventory Management.\n";
                    cout << "3: Feedback Responses.\n";
                    cout << "4: Logout.\n";
                    cin >> employeechoice;
                    cin.ignore();

                    if (employeechoice == 1) {
                        int supportChoice = 0;
                        do {
                            cout << "\n=========== Support Management Options ===========\n";
                            cout << "1. View Support Requests\n";
                            cout << "2. Update Request Status\n";
                            cout << "3. Back to Main Menu\n";
                            cout << "Enter your choice: ";
                            cin >> supportChoice;
                            cin.ignore();

                            if (supportChoice == 1) {
                                viewSupportRequests();
                            }
                            else if (supportChoice == 2) {
                                char* username = new char[50];
                                char* query = new char[200];
                                viewSupportRequests();
                                cout << "Enter Username: ";
                                cin.getline(username, 50);
                                cout << "Enter your answer for this support request: ";
                                cin.getline(query, 200);
                                updateSupportRequestStatus(username, query);

                                cout << "========== Support request status updated successfully ==========\n";
                                delete[] username;
                                delete[] query;
                            }
                        } while (supportChoice != 3);
                    }

                    if (employeechoice == 2) {
                        int* productIDs = new int[100];
                        char names[100][50];
                        float* prices = new float[100];
                        int* stock = new int[100];
                        char categories[100][20];
                        int productCount = 0;
                        int thresholds[100] ; // Threshold levels har product kai liye.

                        loadProductsFromFile(productIDs, names, prices, stock, categories, productCount,thresholds);
                        setAllThresholdsTo10(thresholds, productCount);//yai function har product ka threshold level 10 set kardy ga.
                        int choice;
                        do {
                            cout << "1. Add Product\n";
                            cout << "2. Edit Product\n";
                            cout << "3 Delete Product\n";
                            cout << "4. Adjust Stock\n";
                            cout << "5. Check Low Stock Alerts\n";
                            cout << "6. Exit\n";
                            cout << "Enter your choice: ";
                            cin >> choice;
                            cin.ignore();

                            switch (choice) {
                            case 1: {
                                addProduct(productIDs, names, prices, stock, categories, productCount,thresholds);
                                break;
                            }

                            case 2: {
                                editProduct(productIDs, names, prices, stock, categories, productCount);
                                break;
                            }

                            case 3: {
                                char* productID = new char[40];
                                cout << "Enter ID of product you want to delete: ";
                                cin.getline(productID, 40);
                                if (deleteProduct(productID)) 
                                {
                                    cout << "Product deleted successfully.\n";
                                }
                                else {
                                    cout << "Product not found.\n";
                                }
                                delete[] productID;
                                break;
                            }

                            case 4: {
                                adjustStock(productIDs, names, prices, stock, categories, productCount);
                                break;
                            }
                            case 5:
                                checkLowStock(productIDs, names, stock, thresholds, productCount);
                                break;

                            case 6:
                                cout << "Exiting...\n";
                                break;

                            default:
                                cout << "Invalid choice. Try again.\n";
                            }
                        } while (choice != 6);

                        delete[] productIDs;
                        delete[] prices;
                        delete[] stock;
                    }

                    if (employeechoice == 3) {
                        displayfeedback();

                        char* name = new char[20];
                        char* response = new char[200];
                        cout << "Enter your name to give the response of feedback: ";
                        cin.getline(name, 20);
                        cout << "Enter your response of feedback: ";
                        cin.getline(response, 200);
                        feedbackresponses(response, name);

                        cout << "Feedback response updated.\n";
                        delete[] name;
                        delete[] response;
                    }
                } while (employeechoice != 4);
            }
            if (rol == 1)
            {
                cout << "\n============ Logged in as an Admin!! ============\n\n";
                //is function mai admin sai related saary functions hai
                adminMenu();
                
            }
            else {
                cout << "Access denied. Invalid role.\n";
            }
        }
        else {
            cout << "Invalid credentials.\n";
        }
        break;
    }

    case 3:
        cout << "Exiting program...\n";
        break;

    default:
        cout << "Invalid choice. Try again.\n";
    }

    return 0;
}
