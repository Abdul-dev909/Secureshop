#include"user1.h"
#include"product.h"
// Yeh function existing users ko load karta hai file se
void initializeUsers() {
    const int MAX_USERS = 100;
    const int MAX_LENGTH = 50;

    char usernames[MAX_USERS][MAX_LENGTH];
    char passwords[MAX_USERS][MAX_LENGTH];
    char roles[MAX_USERS][MAX_LENGTH];
    int userCount = 0;

    // File se data load kar rahe hain
    std::ifstream file("C:\\Users\\Abdul\\OneDrive\\Desktop\\PF FINAL PROJECT\\F-project\\Users.txt");
    if (!file) {
        std::cout << "No existing user data found.\n";
        return;  // Agar file nahi mili toh function se return kar jayenge
    }

    char line[100];
    while (file.getline(line, 100)) {
        int i = 0;
        // Line se username ko copy kar rahe hain
        while (line[i] != '\0' && line[i] != '\n') {
            usernames[userCount][i] = line[i];
            i++;
        }
        usernames[userCount][i] = '\0';

        file.getline(line, 100); // Password ke liye doosri line read karte hain
        i = 0;
        while (line[i] != '\0' && line[i] != '\n') {
            passwords[userCount][i] = line[i];
            i++;
        }
        passwords[userCount][i] = '\0';

        file.getline(line, 100); // Role ke liye teesri line read karte hain
        i = 0;
        while (line[i] != '\0' && line[i] != '\n') {
            roles[userCount][i] = line[i];
            i++;
        }
        roles[userCount][i] = '\0';

        userCount++; // Har baar ek user add hone ke baad count badhate hain
    }

    file.close(); // File close karna zaroori hai
}

// Yeh function naya user register karta hai aur data file mein save karta hai
bool registerUser(const char* username, const char* password, const char* role) {
    const int MAX_USERS = 100;
    const int MAX_LENGTH = 50;

    static int userCount = 0;  // Static variable use kar rahe hain taake count maintain ho

    if (userCount >= MAX_USERS) {
        std::cout << "Maximum user limit reached.\n";
        return false;  // Agar maximum limit se zyada users hain toh return false kar dena hai
    }

    // File open kar rahe hain taake naya user add kar sakein
    std::ofstream file("C:\\Users\\Abdul\\OneDrive\\Desktop\\PF FINAL PROJECT\\F-project\\Users.txt", std::ios::app);
    if (!file) {
        std::cout << "Error opening file for registration.\n";
        return false;  // Agar file nahi khuli toh error dekar return karte hain
    }

    // File mein username, password, aur role likh rahe hain
    file << username << std::endl;
    file << password << std::endl;
    file << role << std::endl;
    file.close();

    // Local arrays mein user data store karte hain
    char usernames[MAX_USERS][MAX_LENGTH];
    char passwords[MAX_USERS][MAX_LENGTH];
    char roles[MAX_USERS][MAX_LENGTH];

    // Username copy karte hain local array mein
    int i = 0;
    while (username[i] != '\0') {
        usernames[userCount][i] = username[i];
        i++;
    }
    usernames[userCount][i] = '\0';

    // Password copy karte hain local array mein
    i = 0;
    while (password[i] != '\0') {
        passwords[userCount][i] = password[i];
        i++;
    }
    passwords[userCount][i] = '\0';

    // Role copy karte hain local array mein
    i = 0;
    while (role[i] != '\0') {
        roles[userCount][i] = role[i];
        i++;
    }
    roles[userCount][i] = '\0';

    userCount++; // User count increment karte hain
    return true;
}

// Yeh function user ko login karne ke liye use hota hai
bool loginUser(char* username, char* password) {
    const int MAX_USERS = 100;
    const int MAX_LENGTH = 50;

    char usernames[MAX_USERS][MAX_LENGTH];
    char passwords[MAX_USERS][MAX_LENGTH];
    char roles[MAX_USERS][MAX_LENGTH];
    int userCount = 0;

    // Users.txt file se data load kar rahe hain
    std::ifstream file("Users.txt");
    if (!file) {
        std::cerr << "Error opening file.\n";
        return false;  // Agar file nahi khuli toh login fail ho jata hai
    }

    // File se users read karte hain
    while (file >> usernames[userCount]) {
        file >> passwords[userCount];
        file >> roles[userCount];
        userCount++;
        if (userCount >= MAX_USERS) break; // Maximum limit tak users load karte hain
    }
    file.close();

    // Loop se check karte hain ke username aur password match karta hai ya nahi
    for (int i = 0; i < userCount; i++) {
        if (strcmp1(usernames[i], username) == 0 && strcmp1(passwords[i], password) == 0) {
            std::cout << "Login successful! Role: " << roles[i] << "\n";
            return true;  // Agar match mil gaya toh login successful
        }
    }

    std::cout << "Login failed. Invalid username or password.\n";
    return false; // Agar match nahi mila toh login fail
}

//Role check karny kai liye function
int rolecheck(char* a) 
{
    char ad[] = { "admin" };
    char cus[] = { "customer" };
    char emp[] = { "employee" };
    int adm=1, cust=1, empl=1;
    for (int i = 0; a[i] != '\0'; i++)
    {
        if (a[i] != ad[i])
        {
            adm = 0;
        }
        if (a[i] != cus[i])
        {
            cust = 0;
        }
        if (a[i] != emp[i])
        {
            empl = 0;
        }
    }
    if (adm == 1)
    {
        adm = 1;
        return adm;
    }
    if (cust == 1)
    {
        cust = 2;
        return cust;
    }
    if (empl == 1)
    {
        empl = 3;
        return empl;
    }
    return 0;
}
//Feedback wala function:
using namespace std;
bool addFeedbackToFile(const char* itemId, const char* itemName, const char* feedback,const char* name) {
    ofstream feedbackOut("feedback.txt", ios::app); 
    if (!feedback) {
        cerr << "Error opening feedback file!\n";
        return false;
    }
    feedbackOut << "Customer Name: " << name<<endl;
    feedbackOut << "Item ID: " << itemId << ", Item Name: " << itemName << endl;
    feedbackOut << "Feedback: " << feedback << endl;
    feedbackOut << "---------------------------------------------\n"; 

    feedbackOut.close();
    return true;
}
//WISH LIST WALAY FUNCTIONS:
bool clearWishlist() {
    ofstream wishlistFile("wishlist.txt", ios::trunc); // truncate mode mai khol rahy file kop open karny kai liye
    if (!wishlistFile) {
        cerr << "Error clearing wishlist file!\n";
        return false;
    }

    wishlistFile.close();
    return true;
}
bool addToWishlist(const char* itemId) {
    ofstream wishlistFile("wishlist.txt", ios::app); 
    if (!wishlistFile) {
        cerr << "Error opening wishlist file!\n";
        return false;
    }
    wishlistFile << itemId << endl;  
    wishlistFile.close();
    return true;
}

// Function to display the wishlist
void viewWishlist() {
    ifstream wishlistFile("wishlist.txt");
    if (!wishlistFile) {
        cerr << "Error opening wishlist file!\n";
        return;
    }

    char itemId[50];
    cout << "Your Wishlist:\n";
    while (wishlistFile >> itemId) {
        cout << itemId << endl;  // Display each item in the wishlist
    }
    wishlistFile.close();
}
//Support request kai liye function
bool submitSupportRequest(const char* username, const char* message) 
{
    // file ko append mode mai open kar rahy hai taa kai aur requests add kar saky.
    ofstream supportFile("Support.txt", ios::app);
    if (!supportFile) {
        cerr << "Error opening Support.txt file!\n";
        return false;
    }

    // Write the support request details to the file
    supportFile << "Username: " << username << endl;
    supportFile << "Message: " << message << endl;
    supportFile << "-----------------------------------\n";

    supportFile.close();
    return true;
}