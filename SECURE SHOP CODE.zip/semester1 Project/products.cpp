#include"product.h"
using namespace std;
void productcatalog()
{
    char ID[70];
    char name[70];
    char price[60];
    char quant[70];
    char category[100];
    ifstream file("productcatalog.txt");//File open ki hai catalog kai liye 
    cout << "\n====== PRODUCT CATALOG  ========\n"<<endl;
    cout << "ID\t" << "NAME\t\t" << "PRICE\t\t" << "QUANTITY\t" << "CATEGORY\n";
    while (file >> ID, file >> name, file >> price, file >> quant, file >> category)
    {
        cout << ID << "\t" << name << "\t\t" << price << "\t\t" << quant << "\t    " << category << endl;
    }
    file.close();
}


int strcmp1(char* str1,char* str2)
{
    while (*str1 != '\0' && *str2 != '\0') 
    {
        if (*str1 != *str2)
        {
            return 1; 
        }
        str1++;
        str2++;
    }

    return 0;
}

void filterbycat(char* cat) {
    char* line = new char[200]; // Dynamically allocate line array for each line of file
    char** column = new char* [5]; // Dynamically allocate a 2D array for columns

    for (int i = 0; i < 5; i++) {
        column[i] = new char[50]; // Allocate memory for each column
    }

    int colIndex; // Yeh column ka index track karega

    ifstream file("productcatalog.txt"); // File ko read mode mein open karte hain

    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl; // Agar file nahi khulti, error show karo
        delete[] line;
        for (int i = 0; i < 5; i++) {
            delete[] column[i];
        }
        delete[] column;
        return;
    }

    cout << "Items in the category '" << cat << "':" << endl;

    while (file.getline(line, 200)) { // File line by line read karo
        colIndex = 0;
        int charIndex = 0;

        for (int i = 0; i < 5; i++) { // Har column ko initialize karo
            column[i][0] = '\0';
        }

        // Line ko space ' ' se split karo
        for (int i = 0; line[i] != '\0'; i++) {
            if (line[i] == ' ') {
                column[colIndex][charIndex] = '\0'; // Column complete ho gaya
                colIndex++;
                charIndex = 0;
            }
            else {
                column[colIndex][charIndex++] = line[i];
            }
        }
        column[colIndex][charIndex] = '\0'; // Last column close karo

        // Agar category match kare toh us line ko print karo
        if (colIndex >= 4 && strcmp(column[4], cat) == 0) {
            cout << column[0] << " " << column[1] << " " << column[2] << " " << column[3] << " " << column[4] << endl;
        }
    }

    file.close(); // File ko close karte hain

    // Dynamically allocated memory ko free karo
    delete[] line;
    for (int i = 0; i < 5; i++) {
        delete[] column[i];
    }
    delete[] column;
}

bool additemstocart(char* a) {
    ifstream file("productcatalog.txt"); // File open kar rahe hain product catalog ke liye
    ofstream cart("cart.txt", ios::app); 

    if (!file || !cart) {
        cerr << "Error opening file!" << endl; // Agar file nahi khulti, error show karo
        return false;
    }

    char* id = new char[60];
    char* name = new char[30];
    char* category = new char[30];
    int price, stock;
    bool itemFound = false;

    // File se ek line read karte hain jab tak file khatam na ho
    while (file >> id >> name >> price >> stock >> category) {
        if (strcmp1(id, a) == 0) 
        { // Agar entered ID match kare, toh cart mein add karo
            // Cart file mein item details likho
            cart << id << " " << name << " " << price << " " << stock << " " << category << endl;
            cout << "Item added to cart: " << name << endl; // Confirm karo ke item add hogaya
            itemFound = true;
            updateStock(id, 1);
            break;
        }
    }

    if (!itemFound) {
        cout << "Item with ID " << a << " not found!" << endl; // Agar item nahi milta, error show karo
    }

    file.close();
    cart.close();

    // Dynamically allocated memory ko free karte hain
    delete[] id;
    delete[] name;
    delete[] category;

    return itemFound;
}
void updateStock(char* id, int quantityToRemove) {
    ifstream file("productcatalog.txt");
    ofstream tempFile("temp.txt"); // Temporary file banaya jaha updated data rakha jaye ga

    if (!file.is_open() || !tempFile.is_open()) {
        cerr << "Error opening files!" << endl;
        return;
    }

    // Dynamically arrays bana raha hai for product details
    char* idInFile = new char[60], * name = new char[30], * category = new char[30];
    int price, stock;

    while (file >> idInFile >> name >> price >> stock >> category) {
        if (strcmp1(idInFile, id) == 0) {
            stock -= quantityToRemove; // Jo item remove kiya, uska stock kam karna
            if (stock < 0) stock = 0; // Stock kabhi negative nahi hona chahiye
        }

        // Updated information ko temporary file mein write kar raha hai
        tempFile << idInFile << " " << name << " " << price << " " << stock << " " << category << endl;
    }

    file.close();
    tempFile.close();

    // Temporary file ke data ko wapas original file mein copy karna
    ifstream tempRead("temp.txt");
    ofstream productFile("productcatalog.txt", ios::trunc); // File truncate karke likh raha hai

    char line[200];
    while (tempRead.getline(line, 200)) {
        productFile << line << endl;
    }

    tempRead.close();
    productFile.close();

    // Memory ko free karna zaruri hai
    delete[] idInFile;
    delete[] name;
    delete[] category;
}

bool removeSpecificItem(char* a) {
    ifstream cartFile("cart.txt");
    ofstream tempFile("temp_cart.txt");

    if (!cartFile || !tempFile)
    { 
        cerr << "Error opening files!" << endl;
        return false;
    }
    // Dynamic memory banayi for reading cart data
    char* idInCart = new char[60], * name = new char[30], * category = new char[30];
    int price, stock;
    bool itemFound = false;

    // Cart ke har item ko read kar raha hai, except jo remove karna hai
    while (cartFile >> idInCart >> name >> price >> stock >> category) {
        if (strcmp1(idInCart, a) != 0) {
            tempFile << idInCart << " " << name << " " << price << " " << stock << " " << category << endl;
        }
        else {
            itemFound = true; // Item mil gaya aur remove ho gaya
        }
    }

    cartFile.close();
    tempFile.close();

    // Temporary file ke data ko original cart file mein copy karna
    ifstream tempRead("temp_cart.txt");
    ofstream cartFileWrite("cart.txt", ios::trunc);

    char line[200];
    while (tempRead.getline(line, 200)) {
        cartFileWrite << line << endl;
    }

    tempRead.close();
    cartFileWrite.close();

    // Dynamic memory ko free karna
    delete[] idInCart;
    delete[] name;
    delete[] category;

    return itemFound; // Bataye ga ke item mila aur remove hua ya nahi
}

void clearCart() {
    ofstream cartFile("cart.txt", ios::trunc); // Cart ko truncate kar ke empty karna

    if (!cartFile) {
        cerr << "Error clearing the cart!" << endl;
        return;
    }

    cout << "All items have been removed from the cart." << endl; // Cart successfully clear ho gaya
    cartFile.close();
}

void displaycart() {
    ifstream file("cart.txt");
    char* ID = new char[20];
    char* name = new char[30];
    char* price = new char[30];
    char* categ = new char[50];
    char* line = new char[30]; 
    cout << "\n======  Items in your cart  ======\n";
    cout << "ID\t" << "NAME\t\t" << "PRICE\t\t" << "QUANTITY\t" << "CATEGORY\n";

    while (file>>ID,file>>name,file>>price,file>>line,file>>categ)
    {
        cout << ID <<"\t"<<name<<"\t\t"<<price<<"\t\t"<<"1"<< "\t    " <<categ<< endl;
        // Cart ke items ko display kar raha hai
    }
    delete[] ID;
    delete[] name;
    delete[] price;
    delete[] categ;
    delete[] line; 
    file.close();
}

bool applyDiscount(const char* discountCode, float& discountRate) {
    // Example discount codes ka array aur rates
    const char validCodes[][20] = { "SAVE10", "WELCOME5", "SHOP20" };
    const float discounts[] = { 10.0, 5.0, 20.0 }; // Discounts percentage mein
    int numCodes = 3;

    for (int i = 0; i < numCodes; ++i) {
        if (strcmp(discountCode, validCodes[i]) == 0) {
            discountRate = discounts[i]; // Discount rate set karna
            return true;
        }
    }
    discountRate = 0.0; // Agar code invalid ho, to discount 0
    return false;
}

float calculateTotalAndStoreHistory(const char* cartFile, const char* orderFile, float discountRate) {
    ifstream cart(cartFile);
    ofstream orders(orderFile, ios::app); // Order history append mode mein open

    if (!cart.is_open() || !orders.is_open()) {
        cerr << "Error opening files!\n";
        return -1; // File open failure ka error code
    }

    char id[40], name[50], category[20];
    float price, total = 0.0;
    int quantity;

    // Order history ka header likhna
    orders << "Order Details:\n";
    orders << left << setw(10) << "ID" << setw(20) << "Name" << setw(10) << "Price"
        << setw(10) << "Qty" << setw(15) << "Category" << endl;
    orders << "----------------------------------------------------------\n";

    // Cart items ko read karke total calculate karna
    while (cart >> id >> name >> price >> quantity >> category) {
        float itemTotal = price * 1; // Har item ka total
        total += itemTotal; // Overall total mein add karna

        // Order details ko file mein likhna
        orders << left << setw(10) << id << setw(20) << name << setw(10) << price
            << setw(10) << 1 << setw(15) << category << endl;
    }

    cart.close();

    // Discount ko apply karna agar code valid hai
    float discountAmount = (discountRate / 100) * total;
    float finalTotal = total - discountAmount;

    // Subtotal, discount aur final total ko write karna
    orders << "----------------------------------------------------------\n";
    orders << "Subtotal: " << total << " USD\n";
    if (discountRate > 0) {
        orders << "Discount Applied (" << discountRate << "%): -" << discountAmount << " USD\n";
    }
    orders << "Total: " << finalTotal << " USD\n";
    orders << "==========================================================\n\n";

    orders.close();

    return finalTotal; // Final total return karna
}

bool confirmPurchaseBackend(const char* cartFile, const char* orderFile, float discountRate) {
    // Final total calculate aur order history mein save karna
    float finalTotal = calculateTotalAndStoreHistory(cartFile, orderFile, discountRate);
    if (finalTotal < 0) {
        cout << "Failed to process the purchase.\n";
        return false;
    }

    cout << "Purchase confirmed! Final Total: " << finalTotal << " USD.\n";
    return true; // Purchase confirmation success
}
