#include"employee.h"
#include"product.h"
using namespace std;
// Function to display all support requests
void viewSupportRequests() {
    ifstream supportFile("Support.txt");
    if (!supportFile) {
        cerr << "Error opening Support.txt file!\n";
        return;
    }

    cout << "Customer Support Requests:\n";
    cout << "-----------------------------------\n";

    char line[500];
    while (supportFile.getline(line, 500)) {
        cout << line << endl; // Display each line of the support request
    }

    supportFile.close();
}
//New Support request add karny kai liye function
void updateSupportRequestStatus(const char* username, const char* query) {
    ofstream supportFile("Support.txt", ios::app);  // Open in append mode

    if (!supportFile) {
        cout << "Error opening Support.txt!\n";
        return;
    }


    // Support request ko update karnay kai liye.
    supportFile << "Support request is updated by employee: " << username << '\n';
    supportFile << "Status: Resolved\n";
    supportFile << "Notes: \n"<<query;
    supportFile << "\n------------------------\n";

    supportFile.close();
    cout << "Support request added successfully with status 'resolved'.\n";
}
void displayfeedback()
{
    ifstream feedbackfile("feedback.txt");
    if (!feedbackfile) 
    {
        cerr << "Error opening feedback.txt file!\n";
        return;
    }

    cout << "Customer Feedbacks:\n";
    cout << "-----------------------------------\n";

    char* line=new char[500];
    while (feedbackfile.getline(line, 500))
    {
        cout << line << endl; // Display each line of the support request
    }

}
//feedbacks ka response denay kai liye
void feedbackresponses(char* response,char* username)
{
    ofstream feedbackfile("feedback.txt", ios::app);  // Open in append mode

    if (!feedbackfile) {
        cout << "Error opening Support.txt!\n";
        return;
    }


    // Support request ko update karnay kai liye.
    feedbackfile << "Feedback response given by : " << username << '\n';
    feedbackfile << response;
    feedbackfile << "\n------------------------\n";

    feedbackfile.close();

}
//functions definitions inventory management kai liye
void loadProductsFromFile(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int& productCount, int thresholds[])
{
    ifstream file("productcatalog.txt");
    if (!file) {
        cout << "Error opening file. Starting with an empty catalog.\n";
        productCount = 0;
        return;
    }

    productCount = 0;
    while (file >> productIDs[productCount] >> names[productCount] >> prices[productCount]
        >> stock[productCount] >> categories[productCount])
    {
        thresholds[productCount] = 10;
        productCount++;
    }

    file.close();

}
void saveProductsToFile(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int productCount)
{
    ofstream file("productcatalog.txt");
    if (!file) {
        cout << "Error saving to file.\n";
        return;
    }

    for (int i = 0; i < productCount; i++) {
        file << productIDs[i] << " " << names[i] << " " << prices[i] << " "
            << stock[i] << " " << categories[i] << "\n";
    }

    file.close();

}
void addProduct(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int& productCount, int thresholds[]) {
    cout << "Enter product details:\n";
    cout << "Product ID: ";
    cin >> productIDs[productCount];
    cout << "Name: ";
    cin >> names[productCount];
    cout << "Price: ";
    cin >> prices[productCount];
    cout << "Stock Quantity: ";
    cin >> stock[productCount];
    cout << "Category: ";
    cin >> categories[productCount];
    cin.ignore();

    thresholds[productCount] = 10;

    productCount++;
    saveProductsToFile(productIDs, names, prices, stock, categories, productCount);
    cout << "Product added successfully.\n";
}

void editProduct(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int productCount) 
{
    int id;
    cout << "Enter Product ID to edit: ";
    cin >> id;

    for (int i = 0; i < productCount; i++) {
        if (productIDs[i] == id) {
            cout << "Editing product: " << names[i] << "\n";
            cout << "New Name: ";
            cin >> names[i];
            cout << "New Price: ";
            cin >> prices[i];
            cout << "New Stock Quantity: ";
            cin >> stock[i];
            cout << "New Category: ";
            cin >> categories[i];

            saveProductsToFile(productIDs, names, prices, stock, categories, productCount);
            cout << "Product updated successfully.\n";
            return;
        }
    }
    cout << "Product not found.\n";
}
// stock ki quantity adjust karny kai liye function
void adjustStock(int productIDs[], char names[][50], float prices[], int stock[], char categories[][20], int productCount)
{
    int id, adjustment;
    cout << "Enter Product ID to adjust stock: ";
    cin >> id;

    for (int i = 0; i < productCount; i++) {
        if (productIDs[i] == id) {
            cout << "Current Stock for " << names[i] << ": " << stock[i] << "\n";
            cout << "Enter adjustment amount (positive to add, negative to subtract): ";
            cin >> adjustment;
            stock[i] += adjustment;

            saveProductsToFile(productIDs, names, prices, stock, categories, productCount);
            cout << "Updated Stock: " << stock[i] << "\n";
            return;
        }
    }
    cout << "Product not found.\n";
}
//Productcatalog sai product delete karny wala function
bool deleteProduct(char* productID)
{
    ifstream catalogFile("productcatalog.txt");
    ofstream tempFile("temp_catalog.txt");

    // Check if the files opened successfully
    if (!catalogFile || !tempFile) { // Implicit check for file stream validity
        cerr << "Error opening files!" << endl;
        return false;
    }

    char* idInCatalog = new char[60];
    char* name = new char[50];
    char* category = new char[30];
    float price;
    int stock;
    bool productFound = false;

    
    while (catalogFile >> idInCatalog >> name >> price >> stock >> category) {
        if (strcmp1(idInCatalog, productID) != 0) { // agar id match na kary to osko temp file mai likh dai gai
            tempFile << idInCatalog << " " << name << " " << price << " "
                << stock << " " << category << endl;
        }
        else {
            productFound = true; // Product mil gi aur skipped
        }
    }

    catalogFile.close();
    tempFile.close();

    // asal catalog file ko temp file kai saath badalna
    ifstream tempRead("temp_catalog.txt");
    ofstream catalogFileWrite("productcatalog.txt", ios::trunc);

    char line[200];
    while (tempRead.getline(line, 200)) {
        catalogFileWrite << line << endl;
    }

    tempRead.close();
    catalogFileWrite.close();

    
    delete[] idInCatalog;
    delete[] name;
    delete[] category;

    return productFound; 
}
//low stock ka alert denay kai liye function
void checkLowStock(int productIDs[], char names[][50], int stock[], int thresholds[], int productCount) 
{
    bool alert = false;
    cout << "\n===== Low Stock Alerts =====\n";
    for (int i = 0; i < productCount; i++) {
        if (stock[i] < thresholds[i]) {
            alert = true;
            cout << "Product ID: " << productIDs[i]
                << ", Name: " << names[i]
                << ", Current Stock: " << stock[i]
                << ", Threshold: " << thresholds[i]
                << " --> Restocking Required!\n";
        }
    }
    if (!alert) {
        cout << "All products are sufficiently stocked.\n";
    }
    cout << "=============================\n";
}
//yai function har product ka threshold level 10 set kardy ga.
void setAllThresholdsTo10(int thresholds[], int productCount) {
    for (int i = 0; i < productCount; i++) {
        thresholds[i] = 10;
    }
}