#include"admin.h"
#include"employee.h"
#include"user1.h"
using namespace std;
//Admin ka interface menu show karwany kai liye separate function banaya hai
void adminMenu() {
    int adminchoice = 0;

    do {
        cout << "============== Admin Menu ================\n";
        cout << "1. Users Management.\n";
        cout << "2. Inventory Management.\n";
        cout << "3. Logout\n";
        cout << "\nEnter Your Choice: ";
        cin >> adminchoice;
        cin.ignore();

        if (adminchoice == 1) { // Users management menu
            int choice = 0;
            char* username = new char[30];
            char* password = new char[30];
            char* role = new char[10];
            do {
                cout << "========== Users Management Menu =========\n";
                cout << "1. Add User\n";
                cout << "2. Modify User\n";
                cout << "3. Remove User\n";
                cout << "4. List Users\n";
                cout << "5. Exit\n";
                cout << "Enter your choice: ";
                cin >> choice;
                cin.ignore();

                switch (choice) {
                case 1: // Add a new user
                    cout << "Enter Username of the user you want to add: ";
                    cin >> username;
                    cout << "Enter Password: ";
                    cin >> password;
                    cout << "Enter Role: ";
                    cin >> role;
                    addUser(username, password, role);
                    break;

                case 2: { // Modify an existing user
                    char oldUsername[30];
                    cout << "Enter Username to Modify: ";
                    cin >> oldUsername;
                    cout << "Enter New Username: ";
                    cin >> username;
                    cout << "Enter New Password: ";
                    cin >> password;
                    cout << "Enter New Role: ";
                    cin >> role;
                    modifyUser(oldUsername, username, password, role);
                    break;
                }

                case 3: // Remove a user
                    cout << "Enter Username to Remove: ";
                    cin >> username;
                    removeUser(username);
                    break;

                case 4: // List all users
                    listUsers();
                    break;

                case 5: // Exit users management menu
                    cout << "Exiting User Management Menu...\n";
                    break;

                default:
                    cout << "Invalid choice. Try again.\n";
                }
            } while (choice != 5);
            delete[] username, password, role;
        }
        else if (adminchoice == 2) { // Inventory management menu
            int* productIDs = new int[100];
            char names[100][50];
            float* prices = new float[100];
            int* stock = new int[100];
            char categories[100][20];
            int productCount = 0;
            int thresholds[100]; // Threshold levels har product kai liye

            // Inventory file sai saari products load karlay
            loadProductsFromFile(productIDs, names, prices, stock, categories, productCount, thresholds);
            setAllThresholdsTo10(thresholds, productCount); // Har product ka threshold level 10 set kardo

            int choice;
            do {
                cout << "========== Inventory Management Menu ==========\n";
                cout << "1. Add Product\n";
                cout << "2. Edit Product\n";
                cout << "3. Delete Product\n";
                cout << "4. Adjust Stock\n";
                cout << "5. Check Low Stock Alerts\n";
                cout << "6. Bulk Import Products\n";
                cout << "7. Bulk Export Products\n";
                cout << "8. Exit\n";
                cout << "Enter your choice: ";
                cin >> choice;
                cin.ignore();

                switch (choice) {
                case 1: // Add a new product
                    addProduct(productIDs, names, prices, stock, categories, productCount, thresholds);
                    break;

                case 2: // Edit an existing product
                    editProduct(productIDs, names, prices, stock, categories, productCount);
                    break;

                case 3: { // Delete a product
                    char* productID = new char[40];
                    cout << "Enter ID of product you want to delete: ";
                    cin.getline(productID, 40);
                    if (deleteProduct(productID)) {
                        cout << "Product deleted successfully.\n";
                    }
                    else {
                        cout << "Product not found.\n";
                    }
                    delete[] productID;
                    break;
                }

                case 4: // Adjust stock levels
                    adjustStock(productIDs, names, prices, stock, categories, productCount);
                    break;

                case 5: // Check low stock alerts
                    checkLowStock(productIDs, names, stock, thresholds, productCount);
                    break;

                case 6: { // Bulk import products
                    if (bulkImport()) {
                        cout << "Products imported successfully from bulk_import.txt!\n";
                    }
                    else {
                        cout << "Failed to import products. Check the file path or format.\n";
                    }
                    break;
                }

                case 7: { // Bulk export products
                    if (bulkExport()) {
                        cout << "Products exported successfully to bulk_export.txt!\n";
                    }
                    else {
                        cout << "Failed to export products. Check the file path or permissions.\n";
                    }
                    break;
                }

                case 8: // Exit inventory management menu
                    cout << "Exiting Inventory Management Menu...\n";
                    break;

                default:
                    cout << "Invalid choice. Try again.\n";
                }
            } while (choice != 8);

            delete[] productIDs;
            delete[] prices;
            delete[] stock;
        }
    } while (adminchoice != 3); // Admin menu exit condition
}

//yai wo function hai jis sai admin users add kar sakta hai
void addUser(const char* username, const char* password, const char* role) {
    ofstream file("Users.txt", ios::app);
    if (!file) {
        cout << "Error opening file.\n";
        return;
    }
    file << username << endl << password << endl << role << endl;
    file.close();
    cout << "User added successfully.\n";
}
//saary users ki list show karny kai liye function:
void listUsers()
{
    ifstream file("Users.txt");
    if (!file) {
        cout << "Error opening file.\n";
        return;
    }

    char username[30], password[30], role[10];
    cout << "List of Users:\n";
    while (file >> username >> password >> role) {
        cout << "Username: " << username << ", Role: " << role << endl;
    }
    file.close();
}
//users modify karny kai liye function
bool modifyUser(char* targetUsername, const char* newUsername, const char* newPassword, const char* newRole) 
{
    ifstream userFileRead("users.txt");
    ofstream tempFileWrite("temp_users.txt");

    bool userModified = false;
    char fileUsername[30], filePassword[20], fileRole[10];

    if (!userFileRead || !tempFileWrite) {
        cout << "Error opening files!\n";
        return false;
    }

    while (userFileRead >> fileUsername >> filePassword >> fileRole) {
        if (strcmp1(targetUsername, fileUsername) == 0)//please dehaan dai yaha par 'strcmp1' function use hua hai jisy mai nai khud define kia hai
        {
            // user info update ho rhi yaha
            tempFileWrite << newUsername << " " << newPassword << " " << newRole << endl;
            userModified = true;
        }
        else {
            
            tempFileWrite << fileUsername << " " << filePassword << " " << fileRole << endl;
        }
    }

    userFileRead.close();
    tempFileWrite.close();

    // temp file kai data ko original file mai copy kar rahy
    ifstream tempRead("temp_users.txt");
    ofstream userFileWrite("users.txt", ios::trunc);

    char line[200];
    while (tempRead.getline(line, 200)) {
        userFileWrite << line << endl;
    }

    tempRead.close();
    userFileWrite.close();

    return userModified;
}
//kisi user ko remove karny kai liye function
bool removeUser(char* targetUsername)
{
    ifstream userFileRead("users.txt");
    ofstream tempFileWrite("temp_users.txt");

    bool userRemoved = false;
    char fileUsername[30], filePassword[20], fileRole[10];

    if (!userFileRead || !tempFileWrite) {
        cout << "Error opening files!\n";
        return false;
    }

    while (userFileRead >> fileUsername >> filePassword >> fileRole) {
        if (strcmp1(targetUsername, fileUsername) != 0) {
            // Write only users not matching the target username
            tempFileWrite << fileUsername << " " << filePassword << " " << fileRole << endl;
        }
        else {
            userRemoved = true; // Found the user to remove
        }
    }

    userFileRead.close();
    tempFileWrite.close();

    // Copy temp file data back to original file
    ifstream tempRead("temp_users.txt");
    ofstream userFileWrite("users.txt", ios::trunc);

    char line[200];
    while (tempRead.getline(line, 200)) {
        userFileWrite << line << endl;
    }

    tempRead.close();
    userFileWrite.close();

    return userRemoved;
}
//Bulk import aur export kai liye functions
bool bulkImport()
{
    ifstream bulkFile("bulk_import.txt");
    ofstream catalogFile("productcatalog.txt", ios::app);

    if (!bulkFile || !catalogFile) {
        cout << "Error opening files!\n";
        return false;
    }

    char productID[10], productName[50], category[20];
    int price, quantity;

    while (bulkFile >> productID >> productName >> price >> quantity >> category) {
        catalogFile << productID << " " << productName << " " << price << " " << quantity << " " << category << endl;
    }

    bulkFile.close();
    catalogFile.close();
    return true;
}

bool bulkExport() 
{
    ifstream catalogFile("productcatalog.txt");
    ofstream exportFile("bulk_export.txt");

    if (!catalogFile || !exportFile) {
        cout << "Error opening files!\n";
        return false;
    }

    char line[200];
    while (catalogFile.getline(line, 200)) {
        exportFile << line << endl;
    }

    catalogFile.close();
    exportFile.close();
    return true;
}
